<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
	return view('welcome');
});
Route::view('/', 'welcome')->name('home');

Route::get('/posts', 'PostsController@index')->name('posts');
Route::get('/posts/{id}','PostsController@view')->name('posts.view');


Route::namespace('Admin')->prefix('admin')->name('admin.')->middleware('auth')->group(function() {
	Route::get('categories/{id}/posts','CategoriesController@posts')->name('categories.posts');
	Route::resource('categories','CategoriesController')->names([
		'show' => 'categories.view',
		'index' => 'categories',
	]);


	Route::prefix('posts')->name('posts')->group(function() {
		Route::get('/', 'PostsController@index')->name('');
		
		Route::get('/trashed', 'PostsController@trashed')->name('.trashed');
		Route::put('/trashed/{id}/restore', 'PostsController@restore')->name('.restore');
		Route::delete('/trashed/{id}/delete', 'PostsController@forceDelete')->name('.forceDelete');
		Route::get('/create', 'PostsController@create')->name('.create');
		Route::post('/', 'PostsController@store')->name('.store');
		Route::get('/{id}', 'PostsController@edit')->name('.edit');
		Route::put('/{id}', 'PostsController@update')->name('.update');
		Route::delete('/{id}', 'PostsController@delete')->name('.delete');

		
	});	
	
	Route::resource('tags', 'TagsController')->names([
		'index' => 'tags',
	]);
	
});

Route::get('blog/posts', function() {
	DB::table('posts')
	->groupBy('category_id')
	->having('category_id', '>', 2)
	->dump();
	return;

	return DB::table('categories')
	->inRandomOrder()
            /*->whereExists(function ($query) {
                $query->select(DB::raw(1))
                      ->from('posts')
                      ->whereRaw('posts.category_id = categories.id');
                  })*/
                  ->get();

                  return DB::table('users')
                  ->where('name', '=', 'John')
                  ->where(function ($query) {
                  	$query->where('votes', '>', 100)
                  	->orWhere('title', '=', 'Admin');
                  })->toSql();

                  return DB::table('posts')
				/*->where('post_status', 'published')
				->orWhere([
					['created_at', '>', '2019-06-20'],
					['updated_at', '>', '2019-06-20']
				])*/
				->whereRaw('status = ? OR (created_at > ? AND updated_at > ?)', [
					'published', '2019-06-20', '2019-06-20'
				])
				->toSql();

				return DB::table('categories')
		//->leftJoin('posts', 'posts.category_id', '=', 'categories.id')
				->leftJoin('posts', function($join) {
					$join->on('posts.category_id', '=', 'categories.id')
					->where('posts.status', '=', 'published');
				})
				->select('categories.id', 'categories.name', DB::raw('COUNT(posts.id) as posts_count'))
				->selectRaw('AVG(posts.id) as posts_avg')
				->groupBy('categories.id', 'categories.name')
				->where('posts.status', 'published')
				->orWhere('posts.created_at', '>=', '2019-06-22')
		//->havingRaw('COUNT(posts.id) > :num', ['num' => 1])
				->get();


	//return DB::select('select * from posts');
				$query = DB::table('posts')
				->select('id', 'status');
				if (true) {
					$query->addSelect('title');
				}				
	//->select('title')
	//->distinct()
	//->where('post_status', 'published')
				return $query->get();

				return DB::connection('blog')->select('select * from posts');

	$active = $request->input('active'); // '
	$users = DB::select('select * from users where active = :active AND status = :status', [
		'status' => 1,
		'active' => $active,
	]);

});
Auth::routes(['verify'=> true,]); //for Activate verification links

Route::get('/home', 'HomeController@index')->name('home');
