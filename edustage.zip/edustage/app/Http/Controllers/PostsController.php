<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\PostStat;
use DB;

class PostsController extends Controller
{

    //
    public function index()
    {

        //return Post::all();
        // latest() = orderBy('created_at', 'DESC')
      return view('posts.index')->with([
        //'posts' => Post::where('status', 'published')->latest()->get(),
            'posts' => Post::status()->latest()->simplePaginate(5),
        'title' => '<h2>Title</h2>',
        //'test' => 10,
      ]);
    }

    public function view($id)
    {
        //return Post::find(10);

        //$post = Post::where('status', 'published')->find($id);
        /*$post = Post::where('status', 'published')
                    ->where('id', $id)
                    ->first();*/

        $post = Post::published()->find($id);

      if (!$post) {
        abort(404);
      }
        /*if ($post->status != 'published') {
            abort(404);
        }*/

        $stat = PostStat::updateOrCreate([
            'post_id' => $post->id,
        ], [
            'views' => DB::raw('views + 1'),
        ]);

        //return $stat->post;

      return view('posts.view', [
        'post' => $post,
      ]);
    }
}
