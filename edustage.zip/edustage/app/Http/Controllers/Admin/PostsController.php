<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use App\PostTag;

use DB;

class PostsController extends Controller
{
     public function __construct()
      {
        $this->middleware('auth')->except(['index','trashed']);
        //product all file but index& trashed
    }

    public function index()
    {   
        $title = request()->query('title', '');
        $status = request()->query('status', '');
        $category_id = request()->query('category_id', '');

        $posts = Post::withoutGlobalScope('published')
                    ->with(['category', 'tags'])
                    ->with('stat')
                    //->select('posts.*', 'categories.name as category_name')
                    //->leftJoin('categories', 'posts.category_id', '=', 'categories.id')
                    ->when($title, function($query, $title) {
                        return $query->where('title', 'LIKE', '%' . $title . '%');
                    })
                    ->when($status, function($query, $status) {
                        return $query->where('status', '=', $status);
                    })
                    ->when($category_id, function($query, $category_id) {
                        return $query->where('category_id', '=', $category_id);
                    })
                    ->orderBy('created_at', 'DESC')
                    //->simplePaginate(3)
                    ->paginate(3);

        return view('admin.posts.index', [
            //'posts' => DB::table('posts')->get(),
            'posts' => $posts,
            'title' => $title,
            'status' => $status,
            'category_id' => $category_id,
        ]);
    }

    public function trashed()
    {
        return view('admin.posts.trashed', [
            'posts' => Post::onlyTrashed()->get(),
        ]);
    }

    public function restore(Request $request, $id)
    {
        $post = Post::onlyTrashed()->where('id', '=', $id)->first();
        // $post = Post::onlyTrashed()->findOrFail($id);
        $post->restore();

        return redirect( route('admin.posts') )
                            ->with('message', sprintf('Post "%s" restored!', $post->title));
    }

    public function forceDelete($id)
    {
        //$post = Post::onlyTrashed()->where('id', '=', $id)->first();
        $post = Post::onlyTrashed()->findOrFail($id);
        $post->forceDelete();

        return redirect( route('admin.posts.trashed') )
                            ->with('message', sprintf('Post "%s" deleted!', $post->title));
    }

    public function create()
    {
        return view('admin.posts.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|max:255|min:10',
            'content' => 'required',
            'image' => 'required|image',
            'category_id' => 'required|int',
            //'email' => 'required|email',
            //'date' => 'between:10,255'
        ]);

        $image = $request->file('image');
        $path = $image->store('images', 'public'); // ->storeAs('images', 'image.jpg')

        $post = new Post();
        $post->title = $request->input('title');
        $post->content = $request->input('content');
        $post->image = $path;
        $post->category_id = $request->input('category_id');
        $post->status = $request->input('status');

        $post->save();

        $tags = $request->post('tag');
        $post->tags()->sync($tags);

        //foreach ($tags as $tag_id) {
            /*$postTag = new PostTag();
            $postTag->post_id = $post->id;
            $postTag->tag_id = $tag_id;
            $postTag->save();*/

            //DB::table('post_tag')->insert([
            /*$postTag = PostTag::create([
                'post_id' => $post->id,
                'tag_id' => $tag_id,
            ]);*/
        //}

        return redirect( route('admin.posts') )
                            ->with('message', sprintf('Post "%s" created!', $post->title));
    }

    public function edit($id)
    {
        $post = Post::findOrFail($id);

        //$tags = PostTag::where('post_id', $post->id)->pluck('tag_id')->toArray();

        $tags = $post->tags->pluck('id')->toArray();
        //return  $tags;

        return view('admin.posts.edit', [
            'post' => $post,
            'id' => $id,
            'tags' => $tags,
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|max:255|min:10',
            'content' => 'required',
            'image' => 'image',
            //'category_id' => 'required|int',
            //'email' => 'required|email',
            //'date' => 'between:10,255'
        ]);

        $post = Post::findOrFail($id);

        $image = $request->file('image');

        if ($image && $image->isValid()) {
            $path = $image->storeAs('images', basename($post->image), 'public');
            $post->image = $path;
        }

        $post->title = $request->input('title');
        $post->content = $request->input('content');
        // $post->category_id = $request->input('category_id');
        // $post->status = $request->input('status');
        $post->save();

        $tags = $request->post('tag');
        // return $tags;
        // PostTag::where('post_id',$post->id)->delete();
        // for each(tags as $tag_id){
        //  $postTag = PostTag::create([
        //  'post_id' => $post->id,
        //  'tag_id'  =>$tag_id,
        //  ]);
        // }
        $post->tags()->sync($tags);

        return redirect( route('admin.posts'))->with('message', sprintf('Post "%s" updated!', $post->title));
    }

    public function delete($id)
    {
        $post = Post::findOrFail($id);
        $post->delete();

        return redirect( route('admin.posts'))->with('message', sprintf('Post "%s" deleted!', $post->title));
                            //->with('error', sprintf('Post "%s" deleted!', $post->title));

    }
}
