<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Post extends Model
{
    use SoftDeletes;

    //protected $connection = 'blog';

    protected static function boot()
    {
        parent::boot();

        static::addGlobalScope('published', function($query) {

            $query->where('status', 'published');
        
        });

    }

    public function scopeStatus($query, $status = 'published')
    {
        $query->where('status', $status);

        return $query;
    }


    public function scopePublished($query)
    {
        $query->where('status', 'published');
        //$query->orderBy('created_at', 'DESC');

        return $query;
    }

    public function scopeDraft($query)
    {
        $query->where('status', 'draft');

        return $query;
    }

    public function getPstatusAttribute()
    {
    	return ucfirst($this->status);
    }

    // $post->post_status = "PUBLISHED";
    public function setPstatusAttribute($value)
    {
    	$this->attributes['status'] = strtolower($value);
    }

    // $post->full_name
    public function getFullNameAttribute()
    {
    	return $this->first_name . ' ' . $this->last_name;
    }


 public function category()
    {
        return $this->belongsTo(Category::class,'category_id', 'id')->withDefault([
            'id' => 0,
            'name' => 'Uncategorized',
        ]);
    }
    

     public function stat(){
        return $this->hasOne(PostStat::class,'post_id')->withDefault([
            'views' => 0,
            'likes' => 0,
            'comments' => 0,
        ]);
    }

    public function tags(){
    return $this->belongsToMany(Tag::class,'post_tag','post_id','tag_id');

    }
}
