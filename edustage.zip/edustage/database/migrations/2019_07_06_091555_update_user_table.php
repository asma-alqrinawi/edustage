<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateUserTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            //
            $table->date('birthday')->nullable();
        $table->string('avatar')->after('birthday')->nullable();
        $table->string('country')->after('avatar')->nullable();
        $table->string('username')->after('id')->unique();
        $table->string('lastname')->after('name')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            //
            $table->dropColumn('birthday');
            $table->dropColumn('avatar');
            $table->dropColumn('country');
        });
    }
}
