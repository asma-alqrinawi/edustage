<div class="alert alert-{{ $type }}">
{{ $slot}}
</div>