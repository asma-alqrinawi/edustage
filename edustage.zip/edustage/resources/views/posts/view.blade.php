@extends('layouts.default')

@section('title', $post->title)


@section('content')
  
                        <article class="row blog_item">
                            <div class="col-md-3">
                                <div class="blog_info text-right">
                                    <ul class="blog_meta list">
                                        <li><span class="name">{{ $post->category->name }}</span> <i class="ti-list"></i></li>
                                         <li><span class="name">
                                         	@foreach($post->tags as $tag)
                                         	{{ $tag->name}}
                                         	@endforeach
                                         	</span> <i class="ti-tag"></i></li>
                                        <li><time class="published" style="font-size: 15px;" datetime="{{ $post->created_at }}"> {{ $post->created_at }} </time><i class="ti-calendar"></i></li>
                                        <li>
                                        	<a href="{{ route('posts.view', ['id' => $post->id]) }}">  {{ $post->view }}
				                            </a>
                                                View
                                        		<i class="ti-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="post">
                                   <img height="300" width="500" src="{{ asset('storage/' . $post->image) }}" alt="" />
                                    <div class="blog_details">
                                        <a href="single-blog.html">
                                            <h2>{{ $post->title }}</h2>
                                        </a>
                                        <p>{{ $post->content }}</p>
                                        <a href="single-blog.html" class="blog_btn">View More</a>
                                    </div>
                                       </article>
        
                               
    
              

                 
@endsection

