@extends('layouts.default')

@section('title', 'Edustage Education')

@section('content')
	
	@foreach($posts as $post)
	
	
                        <article class="row blog_item">
                            <div class="col-md-3">
                                <div class="blog_info text-right">
                                    <ul class="blog_meta list">
                                        <li><span class="name">{{ $post->category->name }}</span> <i class="ti-list"></i></li>
                                         <li><span class="name">
                                         	@foreach($post->tags as $tag)
                                         	{{ $tag->name}}
                                         	@endforeach
                                         	</span> <i class="ti-tag"></i></li>
                                        <li><time class="published" style="font-size: 15px;" datetime="{{ $post->created_at }}"> {{ $post->created_at }} </time><i class="ti-calendar"></i></li>
                                        <li>
                                        	View
                                        	{{ $post->stat->views }}  
                                                
                                        	<i class="ti-eye"></i></a></li>
                                    </ul>
                            
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="post">
                                   <img height="300" width="500" src="{{ asset('storage/' . $post->image) }}" alt="" />
                                    <div class="blog_details">
                                        <a href="{{ route('posts.view', ['id' => $post->id]) }}">
                                            <h2>{{ $post->title }}</h2>
                                        </a>
                                        <p>{{ $post->content }}</p>
                                        <a href="{{ route('posts.view', ['id' => $post->id]) }}" class="blog_btn">View More</a>
                                    </div>
                                </div>
                            </div>

                        </article>
                 
                 
	@endforeach
	<div style="margin-left:180px;"> {{ $posts->links() }} </div>
	<!--  <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a href="#" class="page-link" aria-label="Previous">
                                        <span aria-hidden="true">
                                            <i class="ti-angle-left"></i>
                                       </span>
                                    </a>
                                </li>
                                <li class="page-item"><a href="#" class="page-link">01</a></li>
                                <li class="page-item"><a href="#" class="page-link">02</a></li>
                                <li class="page-item"><a href="#" class="page-link">03</a></li>
                                <li class="page-item"><a href="#" class="page-link">04</a></li>
                                <li class="page-item"><a href="#" class="page-link">09</a></li>
                                <li class="page-item">
                                    <a href="#" class="page-link" aria-label="Next">
                                        <span aria-hidden="true">
                                            <i class="ti-angle-right"></i>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                        </nav> -->

	     

@endsection
