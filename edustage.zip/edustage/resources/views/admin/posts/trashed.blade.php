@extends('layouts.admin')

@section('content')
<h2>Trashed Posts</h2>

<table class="table">
	<thead>
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>Deleted At</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
		@foreach ($posts as $post)
		<tr>
			<td>{{ $post->id }}</td>
			<td>{{ $post->title }}</td>
			<td>{{ $post->deleted_at }}</td>
			<td>
				<form method="post" class="form-inline" action="{{ route('admin.posts.restore', ['id' => $post->id]) }}">
					@csrf
					@method('PUT')
					<button type="submit" class="btn btn-sm btn-success">Restore</button>
				</form>
				<form method="post" class="form-inline" action="{{ route('admin.posts.forceDelete', ['id' => $post->id]) }}">
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-sm btn-danger">Delete</button>
				</form>
			</td>
		</tr>
		@endforeach
	</tbody>
</table>

@endsection