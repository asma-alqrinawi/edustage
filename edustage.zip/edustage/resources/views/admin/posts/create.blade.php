@extends('layouts.admin')

@section('content')
<h2>New Post</h2>

@if ($errors->any())
<div class="alert alert-danger">
	<ul>
	@foreach ($errors->all() as $error)
		<li>{{ $error }}</li>
	@endforeach
	</ul>
</div>
@endif

<form method="post" action="{{ route('admin.posts.store') }}" enctype="multipart/form-data">
	@csrf
	<div class="form-group">
		<label class="control-label">Title</label>
		<div>
			<input type="text" name="title" value="{{ old('title') }}" class="form-control @error('title') is-invalid @enderror">
			@error('title')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Category</label>
		<div>
			<select name="category_id" class="form-control @error('category_id') is-invalid @enderror">
				<option>Select Category</option>
				@foreach (App\Category::all() as $category)
				<option value="{{ $category->id }}">{{ $category->name }}</option>
				@endforeach
			</select>
			@error('category_id')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Content</label>
		<div>
			<textarea name="content" class="form-control @error('content') is-invalid @enderror" rows="6">{{ old('content') }}</textarea>
			@error('content')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Image</label>
		<div>
			<input type="file" name="image" class="form-control @error('image') is-invalid @enderror">
			@error('image')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Status</label>
		<div>
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="radio" name="status" value="PUBLISHED">
			  <label class="form-check-label">Published</label>
			</div>
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="radio" name="status" value="DRAFT">
			  <label class="form-check-label">Draft</label>
			</div>

			@error('status')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>

	<div class="form-group">
		<label class="control-label">Tags</label>
		<div>
			@foreach(App\Tag::all() as $tag)
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="checkbox" name="tag[]" value="{{ $tag->id }}">
			  <label class="form-check-label">{{ $tag->name }}</label>
			</div>
			@endforeach
		</div>
	</div>

	<button type="submit" class="btn btn-primary">Save</button>
</form>

@endsection