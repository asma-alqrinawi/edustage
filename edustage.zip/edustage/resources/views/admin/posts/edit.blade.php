@extends('layouts.admin')

@section('content')
<h2>Edit Post</h2>

<form method="post" action="{{ route('admin.posts.update', ['id' => $post->id]) }}" enctype="multipart/form-data">
	@method('PUT')
	@csrf
	<div class="form-group">
		<label class="control-label">Title</label>
		<div>
			<input type="text" name="title" value="{{ old('title', $post->title) }}" class="form-control @error('title') is-invalid @enderror">
			@error('title')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Category</label>
		<div>
			<select name="category_id" class="form-control @error('category_id') is-invalid @enderror">
				<option>Select Category</option>
				@foreach (App\Category::all() as $category)
				<option value="{{ $category->id }}" {{ old('category_id', $post->category_id) == $category->id? ' selected' : '' }}>{{ $category->name }}</option>
				@endforeach
			</select>
			@error('category_id')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Content</label>
		<div>
			<textarea name="content" class="form-control @error('content') is-invalid @enderror" rows="6">{{ old('content', $post->content) }}</textarea>
			@error('content')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Image</label>
		<img src="{{ asset('storage/' . $post->image) }}" height="75">
		<div>
			<input type="file" name="image" class="form-control @error('image') is-invalid @enderror">
			@error('image')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<label class="control-label">Status</label>
		<div>
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="radio" name="status" value="PUBLISHED"
			  {{ old('status', $post->status) == 'published'? ' checked' : '' }}>
			  <label class="form-check-label">Published</label>
			</div>
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="radio" name="status" value="DRAFT"
			  {{ old('status', $post->status) == 'draft'? ' checked' : '' }}>
			  <label class="form-check-label">Draft</label>
			</div>

			@error('status')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>

	<div class="form-group">
		<label class="control-label">Tags</label>
		<div>
			@foreach(App\Tag::all() as $tag)
			<div class="form-check form-check-inline">
			  <input class="form-check-input" type="checkbox" name="tag[]" value="{{ $tag->id }}"
			  {{ in_array($tag->id, $tags)? ' checked' : '' }}>
			  <label class="form-check-label">{{ $tag->name }}</label>
			</div>
			@endforeach
		</div>
	</div>
	<button type="submit" class="btn btn-primary">Save</button>
</form>

@endsection