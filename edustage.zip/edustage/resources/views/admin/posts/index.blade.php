@extends('layouts.admin')

@section('content')
<h2>Posts</h2>

<div class="table-toolbar mb-3">
	<a class="btn btn-light" href="{{ route('admin.posts.create') }}">Add new post</a>
	|
	<a class="btn btn-danger" href="{{ route('admin.posts.trashed') }}">File Trash</a>
</div>

@if (session('message'))
	<div class="alert alert-success">
		{{ session('message') }}
	</div>
@endif

@if (session('error'))
	@component('components.alert')
		@slot('type', 'danger')
	 	{{ session('error') }}
	@endcomponent
@endif

<form method="get" action="{{ route('admin.posts') }}" class="form-inline mb-5 mt-5">
	<input type="text" name="title" placeholder="Search Title..." class="form-control" value="{{ $title }}">
	<select name="status" class="form-control ml-1">
		<option value="">All Status</option>
		<option value="published"{{ $status == 'published'? ' selected' : '' }}>Published</option>
		<option value="draft"{{ $status == 'draft'? ' selected' : '' }}>Draft</option>
	</select>
	<select name="category_id" class="form-control ml-1">
		<option value="">All Categories</option>
		@foreach (App\Category::all() as $category)
		<option value="{{ $category->id }}"{{ $category_id == $category->id? ' selected' : '' }}>{{ $category->name }}</option>
		@endforeach
	</select>
	<button type="submit" class="btn btn-outline-info ml-1">Search</button>
</form>

<table class="table">
	<thead>
		<tr>
			<th>ID</th>
			<th>Title</th>
			<th>Category</th>
			<th>Tags</th>
			<th>Created At</th>
			<th>Updated At</th>
			<th>Status</th>
			<th>Views</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
		@foreach ($posts as $post)
		<tr>
			<td>{{ $post->id }}</td>
			<td>{{ $post->title }}</td>
			<td>{{ $post->category->name }}</td>
			<td>{{-- implode(', ', $post->tags->pluck('name')->toArray()) --}} 
				
				@foreach($post->tags as $tag)
					{{ $tag->name }}

					@if (!$loop->last),
					@endif
				@endforeach
				
			</td>
			<td>{{ $post->created_at->format('W l , F d ,y h:i:s A') }}</td>
			<td>{{ $post->updated_at->format('l , F d ,y h:i:s A') }}</td>
			<td>{{ $post->pstatus }}</td>
			<td>{{ $post->stat->views }}</td>
			<td>
				<a class="btn btn-sm btn-info" href="{{ route('admin.posts.edit', ['id' => $post->id]) }}">Edit</a>
				<form method="post" class="form-inline" style="float: left" action="{{ route('admin.posts.delete', ['id' => $post->id]) }}">
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-sm btn-danger">Delete</button>
				</form>
			</td>
		</tr>
		@endforeach
	</tbody>
</table>

{{ $posts->onEachSide(2)->links() }}

@endsection