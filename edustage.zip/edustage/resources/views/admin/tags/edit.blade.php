@extends('layouts.admin')

@section('content')

<h1>Edit Tag: <small>{{ $tag->name }}</small></h1>

<form action="{{ route('admin.tags.update', ['id' => $tag->id]) }}" method="post">
	@csrf
	@method('PUT')
	<div class="form-group">
		<label>Tag Name:</label>
		<div class="">
			<input type="text" name="name" class="form-control{{ $errors->has('name')? ' is-invalid' : ''}}" value="{{ old('name', $category->name) }}">
			@error('name')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary">Save</button>
	</div>
</form>

@endsection