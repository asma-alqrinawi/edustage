@extends('layouts.admin')

@section('content')
<h1 class="d-flex justify-content-between my-3">
	tags
	<small><a href="{{ route('admin.tags.create') }}">Add</a></small>
</h1>

@if (session('message'))
	<div class="alert alert-success">
		{{ session('success') }}
	</div>
@endif

<table class="table table-striped">
	<thead>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		@foreach ($tags as $tag)
		<tr>
			<td>{{ $tag->id }}</td>
			<td><a href="{{ route('admin.tags.edit', ['id' => $tag->id]) }}">{{ $tag->name }}</a></td>
			<td>
				<form method="post" action="{{ route('admin.tags.destroy', ['id' => $tag->id]) }}">
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-sm btn-danger">Delete</button>
			</td>
		</tr>
		@endforeach
	</tbody>
</table>

{{ $tags->links() }}

@endsection