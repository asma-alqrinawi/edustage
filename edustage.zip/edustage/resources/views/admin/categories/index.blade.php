@extends('layouts.admin')

@section('content')
<h1 class="d-flex justify-content-between my-3">
	Categories
	<small><a href="{{ route('admin.categories.create') }}">Add</a></small>
</h1>

@if (session('message'))
	<div class="alert alert-success">
		{{ session('success') }}
	</div>
@endif

<table class="table table-striped">
	<thead>
		<tr>
			<th>ID</th>
			<th>Name</th>
			<th>Posts</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		@foreach ($categories as $category)
		<tr>
			<td>{{ $category->id }}</td>
			<td><a href="{{ route('admin.categories.edit', ['id' => $category->id]) }}">{{ $category->name }}</a></td>
			<td><a href="{{ route('admin.categories.posts', ['id' => $category->id]) }}">Posts</a></td>
			<td>
				<form method="post" action="{{ route('admin.categories.destroy', ['id' => $category->id]) }}">
					@csrf
					@method('DELETE')
					<button type="submit" class="btn btn-sm btn-danger">Delete</button>
			</td>
		</tr>
		@endforeach
	</tbody>
</table>

{{ $categories->links() }}

@endsection