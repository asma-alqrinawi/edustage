@extends('layouts.admin')

@section('content')

<h1>Add Category</h1>

<form action="{{ route('admin.categories.store') }}" method="post">
	@csrf
	<div class="form-group">
		<label>Category Name:</label>
		<div class="">
			<input type="text" name="name" class="form-control{{ $errors->has('name')? ' is-invalid' : ''}}" value="{{ old('name') }}">
			@error('name')
			<p class="text-danger">{{ $message }}</p>
			@enderror
		</div>
	</div>
	<div class="form-group">
		<button type="submit" class="btn btn-primary">Save</button>
	</div>
</form>

@endsection